﻿Imports System.IO
Module ConnectionString
    Public ReadOnly cs As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\RPOS_DB.accdb"
End Module
